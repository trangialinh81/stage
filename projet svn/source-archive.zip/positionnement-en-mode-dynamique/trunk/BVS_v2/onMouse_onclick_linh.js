<script type="text/ecmascript"><![CDATA[
		
			function onMouseClick(evt) {

				// Get Document
				var target = evt.target;
				var doc = target.ownerDocument;

				// Make test result visible
				var testPassed = doc.getElementById('testPassed');
				testPassed.setAttribute('visibility', 'visible'); 
		
				// Make target invisible
				var target = doc.getElementById('target');
				target.setAttribute('visibility', 'hidden');
			}
		
		]]></script>